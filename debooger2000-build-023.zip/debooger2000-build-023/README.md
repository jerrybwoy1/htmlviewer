# debooger2000 — build 023

A project viewer and debugger for people who are not developers. Open a ZIP, HTML file, or project folder; see the real page; get an honest, plain-English audit — and, if you want, ask an AI helper to explain any finding and suggest a fix.

## Run it

Open `index.html` in any modern browser. Everything works **fully offline** — no internet, no server, no install required. On desktop you can also serve the folder (`python3 -m http.server`) and open it that way; both work.

Two optional features need the internet, and only when you actually use them:

- previewing **React projects that download packages** (esm.sh), because those packages live online;
- the **Ask AI** buttons, because the AI services (Groq / Google AI Studio) live online. Your API key is used only for the request you triggered, is never sent anywhere else, and is kept only in the tab's memory — it is gone when the tab closes.

## What's inside

| File | What it is |
|---|---|
| `index.html` | The complete application — markup, design system, and all app code, organized in labeled module sections inside one file. **This is the authoritative source. Edit this file.** |
| `vendor/jszip.min.js` | JSZip 3.10.1 — opens ZIP uploads and writes project snapshots |
| `vendor/babel.min.js` | Babel standalone 7.29.0 — parses JavaScript/TypeScript and compiles React/JSX previews |
| `vendor/html2canvas.min.js` | html2canvas 1.4.1 — renders page pictures in the parent page |
| `fonts/inter-var.woff2` | Inter variable font (100–900) so the interface looks the same offline |

## The one rule for editing

Everything lives in `index.html`, in clearly labeled sections (build-info, util, device-engine, storage, provider-settings, ai-engine, preview-runtime, project-engine, audit-engine, screenshot-engine, report-engine, app). There is exactly one implementation of each thing. When you change something:

- edit the authoritative section — never bolt on a second copy;
- delete code that stops being used — no dead code, no compatibility shims;
- bump the build number in **one place only**: the `BUILD` constant in the `build-info` section;
- save the result as a **new, uniquely named file or folder** (e.g. build 024) and keep this build untouched as the working backup.

## What build 023 changed

- The saved AI provider keys now actually work. New `ai-engine` module: one place that talks to Groq (`openai/gpt-oss-120b`) or Google AI Studio (`gemini-2.5-flash`), chosen automatically from whichever provider is turned on and has a key.
- New **Ask AI about these results** button (audit level): a simple overall explanation plus a numbered repair order, grounded in the proven findings.
- New per-finding **Explain + suggest a fix with AI** button on every finding card: plain-English FOR YOU explanation plus technical FOR AI repair instructions with file and line.
- Honest failure modes: no provider configured, empty key, rejected key (401/403), rate limit (429), provider outage (5xx), and no internet each get a clear beginner-friendly message. Nothing is ever faked.
- Usage-saving behavior: one request at a time, answers kept for the session only (never re-asked for the same finding), session cache cleared when the project changes, and a Stop waiting button on every request.
- Settings text now tells the truth: keys are used for the request you trigger, kept only in the tab's memory, and the exact model each provider uses is shown.
- Clipboard fallback logic is now one shared helper instead of two copies.
- Page order fix: the detected entry page now always opens first and leads the audit's pictures and button tests. Previously the first-uploaded page (alphabetical) took that role, so opening a project could land on a secondary page.
- Baseline: build 022 (139 audit checks, score hero, safe button tests, page pictures, offline-first).
